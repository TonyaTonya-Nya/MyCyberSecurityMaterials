import angr

# 關閉分析時自動載入的 library
proj = angr.Project('./lab4', load_options={'auto_load_libs': False})
# 載入初始狀態的進入點
state = proj.factory.entry_state()
# 建立 simulation manager 求解器
simgr = proj.factory.simgr(state)
# 顯示程式執行位址
print(simgr.active)
# 設定路徑
print(simgr.explore(find=0x400000+0x0849, avoid=0x400000+0x085A))
# 顯示結果
print(simgr.found[0].posix.dumps(0))


