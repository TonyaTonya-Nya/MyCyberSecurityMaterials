import angr
import claripy

# program path
path = './lab6'
# Constant
BASE_ADDRESS = 0x400000
find = 0x18f7
avoid = 0x18f9
# 約束條件輸入
argv1 = claripy.BVS("argv1",100*8) 
# 關閉分析時自動載入的 library
proj = angr.Project(path, load_options={'auto_load_libs': False})
# 載入初始狀態的進入點，包含約束條件參數
state = proj.factory.entry_state(args=[path,argv1])
# 建立 simulation manager 求解器
simgr = proj.factory.simgr(state)
# 顯示程式執行位址
print(simgr.active)
# 設定路徑
print(simgr.explore(find=BASE_ADDRESS+find))
# 顯示結果
print(simgr.found[0].solver.eval(argv1, cast_to=bytes))

